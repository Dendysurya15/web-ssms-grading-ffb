<!DOCTYPE html>
<html>

<head>
    <title>GRADING TBS SKM</title>
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('img/CBI-logo.png') }}">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container " style="margin-top: 3%">

        @yield('content')
    </div>
</body>

</html>